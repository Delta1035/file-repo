package com.wistron.avatar.sfclinestage.mapper.oraclekpi;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wistron.avatar.common.entity.oraclekpi.SfcLineStageTempHxyEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ISfcLineStageTempHxyMapper extends BaseMapper<SfcLineStageTempHxyEntity> {
}
