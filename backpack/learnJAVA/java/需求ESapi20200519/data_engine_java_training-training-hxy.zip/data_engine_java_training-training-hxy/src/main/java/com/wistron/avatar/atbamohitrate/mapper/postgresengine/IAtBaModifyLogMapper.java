package com.wistron.avatar.atbamohitrate.mapper.postgresengine;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wistron.avatar.common.entity.postgresengine.AtBaModifyLogEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IAtBaModifyLogMapper extends BaseMapper<AtBaModifyLogEntity> {
}
