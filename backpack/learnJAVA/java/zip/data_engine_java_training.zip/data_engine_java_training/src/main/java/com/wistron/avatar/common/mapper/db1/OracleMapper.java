package com.wistron.avatar.common.mapper.db1;

public class OracleMapper {
}
