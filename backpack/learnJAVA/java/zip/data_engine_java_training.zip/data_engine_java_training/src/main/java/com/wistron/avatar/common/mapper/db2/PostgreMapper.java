package com.wistron.avatar.common.mapper.db2;

public class PostgreMapper {
}
