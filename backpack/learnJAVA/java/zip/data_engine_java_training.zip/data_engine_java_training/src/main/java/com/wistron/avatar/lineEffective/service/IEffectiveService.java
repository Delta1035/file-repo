package com.wistron.avatar.lineEffective.service;

public interface IEffectiveService {

    public List test(){
        return
    }
}
