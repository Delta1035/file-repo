package com.wistron.avatar.basic.samples;

public class IfElseStatements {

	public static void main(String args[]) {
		int a = 30, b = 30;

		if (b > a) {
			System.out.println("b is greater");
		} else if (a > b) {
			System.out.println("a is greater");
		} else {
			System.out.println("Both are equal");
		}
	}
}