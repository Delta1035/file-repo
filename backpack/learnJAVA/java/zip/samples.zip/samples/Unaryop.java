package com.wistron.avatar.basic.samples;

public class Unaryop {
	public static void main(String[] args) {
		int r = 6;
		System.out.println("r=: " + r++);
		System.out.println("r=: " + r);

		int x = 6;
		System.out.println("x=: " + x--);
		System.out.println("x=: " + x);

		int y = 6;
		System.out.println("y=: " + ++y);

		int p = 6;
		System.out.println("p=: " + --p);
	}
}