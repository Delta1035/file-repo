import React from 'react'
import * as Style from '../../ProjectListStyle'
import Icon from '../../../../icon/Icon'

export default function RfqFile () {
  return (
    <Style.File>
      <Icon.File />
      RFQ PRD File
    </Style.File>

  )
}
