import React from 'react';

export default function NoPermission () {
  return (
    <div>403 NoPermission</div>
  )
}
