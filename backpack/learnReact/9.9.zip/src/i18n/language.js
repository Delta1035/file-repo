export const languages = {
  zh: {
    projectmember: '專案成員'
  },
  en: {
    projectmember: 'Members of the project'
  }
  // 一个是对应的中文的语言 一个对应的英文 hello的key就相当与一个映射
}
