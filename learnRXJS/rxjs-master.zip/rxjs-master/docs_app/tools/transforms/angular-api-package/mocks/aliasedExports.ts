export * from './operator';
export { operator as aliasedOperator } from './operator';
export { operator } from './operator';
export { anotherOperator as operatorWithoutDuplicate } from './anotherOperator';
