export const anotherOperator = () => {};
