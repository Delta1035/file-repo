module.exports = function() {
  return {name: 'syntax'};
};