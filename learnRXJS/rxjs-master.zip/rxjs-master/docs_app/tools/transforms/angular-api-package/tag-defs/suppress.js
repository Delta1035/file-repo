module.exports = function() {
  return {name: 'suppress'};
};