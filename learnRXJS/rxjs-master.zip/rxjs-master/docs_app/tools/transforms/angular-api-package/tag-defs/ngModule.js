module.exports = function() {
  return {name: 'ngModule'};
};
