// A ts2dart compiler annotation that can be ignored in API docs.
module.exports = function() {
  return {name: 'Annotation', ignore: true};
};
