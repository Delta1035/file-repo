// A ts2dart compiler annotation that can be ignored in API docs.
module.exports = function() {
  return {name: 'ts2dart_const', ignore: true};
};
