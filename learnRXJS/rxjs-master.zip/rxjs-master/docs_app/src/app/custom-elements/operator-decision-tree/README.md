The `operator-decision-tree` module requires `decision-tree-data.json`, which is hosted at `/generated/app`.

The JSON is generated via the `docs_app/tools/decision-tree-generator`.

# TODO
- Consider placing the widget on the home page - or a link on the home page, “Decision Tree”
- Manual focus calls when navigating the tree (example: after making a selection, focus on the current sentence)
- Drop jasmine-marbles for just the TestScheduler