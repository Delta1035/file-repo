// This is for archived sites, which are hosted at https://vX.angular.io, where X is the major Angular version.
export const environment = {
  gaId: 'UA-36380079-2', // Production id (since it is linked from the main site)
  production: true,
  mode: 'archive'
};
