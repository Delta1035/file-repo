export const INJECTIONS_MD_KEY: string = 'DI:injections';
export const INJECTABLE_MD_KEY: string = 'DI:injectable';