// https://github.com/vueComponent/ant-design-vue/blob/master/components/style/themes/default.less
module.exports = {
    "primary-color": "#008dff",
    "link-color": "#87b4e2",
};
