/**
 * @author: Tusi
 * @description: jshashes类型定义
 */
declare module "jshashes" {
    export class SHA256 {
        public hex: (string) => string;
    }
}